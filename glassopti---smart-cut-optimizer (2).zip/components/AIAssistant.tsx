import React, { useState, useEffect, useRef } from 'react';
import { GoogleGenAI } from "@google/genai";
import { Message, OptimizationResult, RequiredPart, StockSheet } from '../types';
import { Send, Sparkles, Bot, User, Loader2 } from 'lucide-react';

interface Props {
  result: OptimizationResult | null;
  parts: RequiredPart[];
  stock: StockSheet[];
  unit: 'mm' | 'inch';
}

const AIAssistant: React.FC<Props> = ({ result, parts, stock, unit }) => {
  const [messages, setMessages] = useState<Message[]>([
    { role: 'model', text: 'Hi! I can help you analyze your cutting plan, suggest material types, or give safety tips. What do you need?', timestamp: Date.now() }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim()) return;
    
    const userMsg: Message = { role: 'user', text: input, timestamp: Date.now() };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setLoading(true);

    try {
      const apiKey = process.env.API_KEY;
      if (!apiKey) {
        throw new Error("API Key not found");
      }

      const ai = new GoogleGenAI({ apiKey });
      
      // Construct context
      const context = `
        You are an expert Glass Cutting and Optimization Assistant.
        
        Current Project Context:
        - Units: ${unit}
        - Total Parts Required: ${parts.length}
        - Stock Sheets Available: ${stock.length} types.
        - Last Optimization Result: ${result ? `Efficiency: ${result.efficiency.toFixed(2)}%, Sheets Used: ${result.sheets.length}, Waste: ${result.totalWaste.toFixed(2)}%` : "No optimization run yet."}
        - Unplaced Parts: ${result?.unplacedParts.length || 0}
        
        User Query: ${userMsg.text}
        
        Provide helpful, concise, and professional advice. If the efficiency is low (<80%), suggest changing stock sizes.
        If asked about glass types, explain differences (Tempered, Laminated, Float).
      `;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: [{ role: 'user', parts: [{ text: context }] }],
        config: {
            systemInstruction: "You are a helpful assistant for a Glass Cutting Optimizer app.",
        }
      });

      const text = response.text || "I couldn't generate a response.";
      
      setMessages(prev => [...prev, { role: 'model', text, timestamp: Date.now() }]);

    } catch (error) {
      console.error(error);
      setMessages(prev => [...prev, { role: 'model', text: "Sorry, I encountered an error connecting to the AI service. Please check your API key.", timestamp: Date.now() }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-[600px] bg-white rounded-xl shadow-xl border border-slate-200 overflow-hidden">
      <div className="bg-gradient-to-r from-indigo-600 to-purple-600 p-4 flex items-center gap-2">
        <Sparkles className="text-yellow-300 w-5 h-5" />
        <h2 className="text-white font-bold text-lg">AI Project Assistant</h2>
      </div>

      <div className="flex-1 overflow-y-auto p-4 bg-slate-50 space-y-4">
        {messages.map((msg, idx) => (
          <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`flex gap-2 max-w-[80%] ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${msg.role === 'user' ? 'bg-indigo-100 text-indigo-600' : 'bg-emerald-100 text-emerald-600'}`}>
                {msg.role === 'user' ? <User size={16} /> : <Bot size={16} />}
              </div>
              <div className={`p-3 rounded-lg text-sm shadow-sm ${msg.role === 'user' ? 'bg-indigo-600 text-white rounded-tr-none' : 'bg-white text-slate-700 border border-slate-200 rounded-tl-none'}`}>
                {msg.text}
              </div>
            </div>
          </div>
        ))}
        {loading && (
           <div className="flex justify-start">
            <div className="flex gap-2 max-w-[80%]">
               <div className="w-8 h-8 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center">
                 <Bot size={16} />
               </div>
               <div className="bg-white p-3 rounded-lg border border-slate-200 flex items-center gap-2 text-slate-500 text-sm">
                 <Loader2 className="w-4 h-4 animate-spin" /> Thinking...
               </div>
            </div>
           </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <div className="p-4 bg-white border-t border-slate-200">
        <div className="flex gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Ask about waste, glass types, or costs..."
            className="flex-1 border border-slate-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
          />
          <button 
            onClick={handleSend}
            disabled={loading}
            className="bg-indigo-600 hover:bg-indigo-700 text-white p-2 rounded-lg transition-colors disabled:opacity-50"
          >
            <Send size={20} />
          </button>
        </div>
      </div>
    </div>
  );
};

export default AIAssistant;