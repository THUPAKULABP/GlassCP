import React, { useEffect, useRef, useState } from 'react';
import * as d3 from 'd3';
import { UsedSheet, Rect } from '../types';
import { Download, Printer, Box, Maximize, ChevronDown, FileText, Image as ImageIcon } from 'lucide-react';

interface Props {
  sheet: UsedSheet;
  index: number;
  is3D: boolean;
  unit: 'mm' | 'inch';
}

const LayoutViewer: React.FC<Props> = ({ sheet, index, is3D, unit }) => {
  const svgRef = useRef<SVGSVGElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const menuRef = useRef<HTMLDivElement>(null);
  const uniqueId = `layout-viewer-${index}`;
  const [showMenu, setShowMenu] = useState(false);

  // Close menu when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setShowMenu(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // 2D Render Effect
  useEffect(() => {
    if (!svgRef.current || is3D) return;

    const svg = d3.select(svgRef.current);
    svg.selectAll("*").remove();

    const margin = { top: 30, right: 30, bottom: 30, left: 30 };
    const containerWidth = containerRef.current?.clientWidth || 800;
    const aspectRatio = sheet.height / sheet.width;
    const width = containerWidth - margin.left - margin.right;
    const height = width * aspectRatio;

    // Define Hatch Pattern for Waste/Empty Areas
    const defs = svg.append("defs");
    defs.append("pattern")
        .attr("id", `diagonalHatch-${uniqueId}`)
        .attr("patternUnits", "userSpaceOnUse")
        .attr("width", 10)
        .attr("height", 10)
        .append("path")
        .attr("d", "M-1,1 l2,-2 M0,10 l10,-10 M9,11 l2,-2")
        .attr("stroke", "#cbd5e1") // slate-300
        .attr("stroke-width", 1);

    svg.attr("viewBox", `0 0 ${width + margin.left + margin.right} ${height + margin.top + margin.bottom}`)
       .attr("height", height + margin.top + margin.bottom);

    const g = svg.append("g")
                 .attr("transform", `translate(${margin.left},${margin.top})`);

    const xScale = d3.scaleLinear().domain([0, sheet.width]).range([0, width]);
    const yScale = d3.scaleLinear().domain([0, sheet.height]).range([0, height]);

    // Draw Main Sheet Outline (Base)
    g.append("rect")
     .attr("x", 0)
     .attr("y", 0)
     .attr("width", width)
     .attr("height", height)
     .attr("fill", "#f8fafc") // slate-50 background
     .attr("stroke", "#475569") // slate-600 outer border
     .attr("stroke-width", 2);

    // Draw Waste Areas (Free Rects) using Hatch Pattern
    g.selectAll(".free-rect")
     .data(sheet.freeRects)
     .enter()
     .append("rect")
     .attr("x", d => xScale(d.x))
     .attr("y", d => yScale(d.y))
     .attr("width", d => xScale(d.width))
     .attr("height", d => yScale(d.height))
     .attr("fill", `url(#diagonalHatch-${uniqueId})`)
     .attr("stroke", "#94a3b8") // slate-400
     .attr("stroke-width", 1)
     .attr("stroke-dasharray", "4,2");

    // Draw Cut Parts
    const cuts = g.selectAll(".cut")
                  .data(sheet.cuts)
                  .enter()
                  .append("g")
                  .attr("class", "cut")
                  .attr("transform", d => `translate(${xScale(d.x)}, ${yScale(d.y)})`);

    cuts.append("rect")
        .attr("width", d => xScale(d.width))
        .attr("height", d => yScale(d.height))
        .attr("fill", d => d.data?.color || "#3b82f6")
        .attr("stroke", "#0f172a") // slate-900 (Dark solid line for cut boundary)
        .attr("stroke-width", 1.5) // Slightly thicker to pop out
        .attr("opacity", 0.85)
        .on("mouseover", function() { d3.select(this).attr("opacity", 1).attr("stroke-width", 2); })
        .on("mouseout", function() { d3.select(this).attr("opacity", 0.85).attr("stroke-width", 1.5); });

    // Center Label
    cuts.append("text")
        .attr("x", d => xScale(d.width) / 2)
        .attr("y", d => yScale(d.height) / 2)
        .attr("dy", "0.35em")
        .attr("text-anchor", "middle")
        .text(d => d.data?.label || "")
        .attr("fill", "#ffffff") // White text for better contrast on colored parts
        .attr("stroke", "#000000")
        .attr("stroke-width", 0.5)
        .attr("paint-order", "stroke")
        .attr("font-size", d => Math.max(10, Math.min(xScale(d.width), yScale(d.height)) / 6))
        .attr("font-weight", "bold")
        .style("pointer-events", "none");
    
    // Add Tooltip Title
    cuts.append("title")
        .text(d => {
            const label = d.data?.label || "Part";
            const dim = `${d.width} x ${d.height} ${unit}`;
            const desc = d.data?.description ? `\n\n${d.data.description}` : "";
            return `${label}\n${dim}${desc}`;
        });

    // Edge Dimensions Logic
    const fontSize = 10;
    
    // Top Edge Width
    cuts.each(function(d) {
      if (xScale(d.width) < 30) return; // Skip if too small
      d3.select(this).append("text")
        .attr("x", xScale(d.width) / 2)
        .attr("y", 2)
        .attr("dy", "0.8em")
        .attr("text-anchor", "middle")
        .text(d.width)
        .attr("font-size", fontSize)
        .attr("fill", "rgba(0,0,0,0.7)");
    });

    // Bottom Edge Width
    cuts.each(function(d) {
      if (xScale(d.width) < 30 || yScale(d.height) < 30) return;
      d3.select(this).append("text")
        .attr("x", xScale(d.width) / 2)
        .attr("y", yScale(d.height) - 2)
        .attr("text-anchor", "middle")
        .text(d.width)
        .attr("font-size", fontSize)
        .attr("fill", "rgba(0,0,0,0.7)");
    });

    // Left Edge Height
    cuts.each(function(d) {
       if (yScale(d.height) < 30) return;
       d3.select(this).append("text")
        .attr("transform", `translate(2, ${yScale(d.height)/2}) rotate(-90)`)
        .attr("dy", "0.8em")
        .attr("text-anchor", "middle")
        .text(d.height)
        .attr("font-size", fontSize)
        .attr("fill", "rgba(0,0,0,0.7)");
    });

    // Right Edge Height
    cuts.each(function(d) {
       if (yScale(d.height) < 30 || xScale(d.width) < 30) return;
       d3.select(this).append("text")
        .attr("transform", `translate(${xScale(d.width)-2}, ${yScale(d.height)/2}) rotate(-90)`)
        .attr("text-anchor", "middle")
        .text(d.height)
        .attr("font-size", fontSize)
        .attr("fill", "rgba(0,0,0,0.7)");
    });

    // Outer Dimensions
    g.append("text")
     .attr("x", width / 2)
     .attr("y", -10)
     .attr("text-anchor", "middle")
     .attr("fill", "#64748b")
     .attr("font-size", "14px")
     .attr("font-weight", "bold")
     .text(`${sheet.width}${unit}`);

    g.append("text")
     .attr("transform", `rotate(-90)`)
     .attr("x", -height / 2)
     .attr("y", -10)
     .attr("text-anchor", "middle")
     .attr("fill", "#64748b")
     .attr("font-size", "14px")
     .attr("font-weight", "bold")
     .text(`${sheet.height}${unit}`);

  }, [sheet, is3D, unit, uniqueId]);

  const handleDownload = () => {
    if (is3D) return; // Not supported for 3D yet
    if (!svgRef.current) return;

    const serializer = new XMLSerializer();
    const svgString = serializer.serializeToString(svgRef.current);
    const blob = new Blob([svgString], { type: "image/svg+xml;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    
    // Convert to PNG for better user compatibility
    const canvas = document.createElement('canvas');
    const img = new Image();
    img.onload = () => {
        canvas.width = svgRef.current!.clientWidth * 2; // High res
        canvas.height = svgRef.current!.clientHeight * 2;
        const ctx = canvas.getContext('2d');
        if(ctx) {
            ctx.scale(2, 2);
            ctx.fillStyle = "white";
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            ctx.drawImage(img, 0, 0);
            const pngUrl = canvas.toDataURL("image/png");
            const link = document.createElement("a");
            link.href = pngUrl;
            link.download = `layout-sheet-${index+1}.png`;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }
    };
    img.src = url;
  };

  const handlePrint = () => {
    // Create a unique style element to hide everything but this component
    const style = document.createElement('style');
    style.innerHTML = `
      @media print {
        body * {
          visibility: hidden;
        }
        #${uniqueId}, #${uniqueId} * {
          visibility: visible;
        }
        #${uniqueId} {
          position: absolute;
          left: 0;
          top: 0;
          width: 100%;
          margin: 0;
          padding: 0;
          box-shadow: none;
          border: none;
          background: white;
        }
        /* Hide tool buttons in print */
        .print-hidden { display: none !important; }
      }
    `;
    document.head.appendChild(style);
    window.print();
    document.head.removeChild(style);
  };
  
  // Wrapper for PDF to ensure menu closes
  const handlePdfClick = () => {
      setShowMenu(false);
      // Small timeout to allow render cycle to close menu before print dialog freezes UI
      setTimeout(() => {
          handlePrint();
      }, 50);
  };

  // Wrapper for PNG
  const handlePngClick = () => {
      setShowMenu(false);
      handleDownload();
  };

  return (
    <div id={uniqueId} ref={containerRef} className="break-inside-avoid bg-white p-4 rounded-lg shadow-md border border-slate-200 mb-6 print:shadow-none print:border-none print:mb-0 print:break-inside-avoid">
      <div className="flex justify-between items-center mb-2 border-b pb-2 print:hidden">
        <h3 className="font-bold text-slate-700">Sheet #{index + 1} <span className="text-slate-400 font-normal">({sheet.width} x {sheet.height} {unit})</span></h3>
        <div className="flex items-center gap-4">
           <div className="flex gap-4 text-sm mr-4">
            <span className="text-slate-500">Waste: <span className="font-mono font-bold text-red-500">{sheet.waste.toFixed(1)}%</span></span>
          </div>
          <div className="flex gap-2 print-hidden items-center">
            {/* Download Dropdown */}
            <div className="relative" ref={menuRef}>
                <button 
                    onClick={() => setShowMenu(!showMenu)}
                    className={`flex items-center gap-1 px-3 py-1.5 text-sm font-medium rounded transition-colors ${showMenu ? 'bg-indigo-50 text-indigo-600 ring-2 ring-indigo-100' : 'bg-white text-slate-600 hover:bg-slate-50 border border-slate-200'}`}
                    title="Download Options"
                >
                    <Download size={16} />
                    <span className="hidden sm:inline">Download</span>
                    <ChevronDown size={14} className={`transition-transform duration-200 ${showMenu ? 'rotate-180' : ''}`}/>
                </button>
                
                {showMenu && (
                    <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-xl border border-slate-100 z-50 overflow-hidden animate-in fade-in zoom-in-95 duration-100 origin-top-right">
                         {!is3D && (
                            <button onClick={handlePngClick} className="w-full text-left px-4 py-3 text-sm text-slate-700 hover:bg-slate-50 flex items-center gap-3 border-b border-slate-50 transition-colors">
                                <ImageIcon size={16} className="text-blue-500"/>
                                <div>
                                    <span className="block font-medium">Download PNG</span>
                                    <span className="block text-[10px] text-slate-400">High Resolution Image</span>
                                </div>
                            </button>
                         )}
                         <button onClick={handlePdfClick} className="w-full text-left px-4 py-3 text-sm text-slate-700 hover:bg-slate-50 flex items-center gap-3 transition-colors">
                            <FileText size={16} className="text-red-500"/>
                            <div>
                                <span className="block font-medium">Download PDF</span>
                                <span className="block text-[10px] text-slate-400">Print Friendly Format</span>
                            </div>
                         </button>
                    </div>
                )}
            </div>
          </div>
        </div>
      </div>
      
      {/* Print Header (Visible only in print) */}
      <div className="hidden print:block mb-2">
          <h3 className="font-bold text-black text-lg">Sheet #{index + 1} - {sheet.width}{unit} x {sheet.height}{unit}</h3>
          <p className="text-sm text-slate-600">Efficiency: {(100 - sheet.waste).toFixed(1)}%</p>
      </div>

      <div className={`w-full h-auto aspect-video bg-slate-50 rounded flex items-center justify-center overflow-hidden transition-all ${is3D ? 'perspective-1000' : ''} print:bg-white`}>
        {is3D ? (
          // 3D View
          <div className="relative transition-transform duration-700 ease-out transform-style-3d" 
               style={{ 
                   width: '80%', 
                   height: '80%',
                   aspectRatio: `${sheet.width}/${sheet.height}`,
                   transform: 'rotateX(45deg) rotateZ(-10deg) translateZ(0px)',
                   boxShadow: '20px 20px 50px rgba(0,0,0,0.2)'
               }}>
             {/* Base Sheet */}
             <div className="absolute inset-0 bg-blue-50/30 border-2 border-slate-300 backdrop-blur-sm shadow-lg"></div>
             
             {/* Cuts */}
             {sheet.cuts.map((cut, i) => (
                 <div key={i} 
                      className="absolute border border-white/50 shadow-sm hover:translate-z-2 transition-transform duration-300 group"
                      title={`${cut.data?.label}\n${cut.width} x ${cut.height} ${unit}${cut.data?.description ? `\n\n${cut.data.description}` : ''}`}
                      style={{
                          left: `${(cut.x / sheet.width) * 100}%`,
                          top: `${(cut.y / sheet.height) * 100}%`,
                          width: `${(cut.width / sheet.width) * 100}%`,
                          height: `${(cut.height / sheet.height) * 100}%`,
                          backgroundColor: cut.data?.color || '#3b82f6',
                          opacity: 0.85
                      }}>
                    {/* 3D Thickness Effect (Pseudo-ish) */}
                    <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                        <span className="bg-black/70 text-white text-xs px-1 rounded">{cut.data?.label}</span>
                    </div>
                 </div>
             ))}
          </div>
        ) : (
          // 2D View
          <svg ref={svgRef} className="w-full h-full"></svg>
        )}
      </div>
    </div>
  );
};

export default LayoutViewer;