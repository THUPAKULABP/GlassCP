import { RequiredPart, StockSheet, UsedSheet, Rect, OptimizationResult, OptimizationMode } from '../types';

// Guillotine Packer Implementation
class GuillotinePacker {
  width: number;
  height: number;
  freeRectangles: Rect[];
  placedRectangles: Rect[];
  kerf: number;

  constructor(width: number, height: number, kerf: number = 0) {
    this.width = width;
    this.height = height;
    this.kerf = kerf;
    this.freeRectangles = [{ x: 0, y: 0, width: width, height: height, rotated: false }];
    this.placedRectangles = [];
  }

  fit(parts: RequiredPart[], allowRotation: boolean) {
    for (const part of parts) {
      // Try to fit the rect
      const bestNode = this.findBestScore(part.width, part.height, allowRotation);
      
      if (bestNode.score !== Number.MAX_VALUE) {
        this.placeRect(bestNode.rect);
        // Store metadata
        this.placedRectangles[this.placedRectangles.length - 1].data = part;
      } else {
        // Could not fit in this sheet
        return false; 
      }
    }
    return true;
  }

  // Find best free rectangle using Best Area Fit (BAF)
  findBestScore(width: number, height: number, allowRotation: boolean) {
    let bestScore = Number.MAX_VALUE;
    let bestRect: Rect | null = null;

    // Add kerf to required dimensions for placement check
    const effW = width + this.kerf;
    const effH = height + this.kerf;

    for (const freeRect of this.freeRectangles) {
      // Try normal orientation
      if (freeRect.width >= effW && freeRect.height >= effH) {
        const score = freeRect.width * freeRect.height - effW * effH;
        if (score < bestScore) {
          bestScore = score;
          bestRect = { x: freeRect.x, y: freeRect.y, width: width, height: height, rotated: false };
        }
      }

      // Try rotated
      if (allowRotation && freeRect.width >= effH && freeRect.height >= effW) {
        const score = freeRect.width * freeRect.height - effH * effW;
        if (score < bestScore) {
          bestScore = score;
          bestRect = { x: freeRect.x, y: freeRect.y, width: height, height: width, rotated: true };
        }
      }
    }

    return { score: bestScore, rect: bestRect! };
  }

  placeRect(rect: Rect) {
    // Find the split
    const effW = rect.width + this.kerf;
    const effH = rect.height + this.kerf;
    
    let nodeIndex = -1;
    // Find the free rect we are using
    for(let i=0; i<this.freeRectangles.length; i++) {
        const fr = this.freeRectangles[i];
        if (fr.x === rect.x && fr.y === rect.y) {
            nodeIndex = i;
            break;
        }
    }
    
    if (nodeIndex === -1) return;

    const freeRect = this.freeRectangles[nodeIndex];
    
    // Split by Shorter Axis Rule
    const w = effW;
    const h = effH;

    // New free rectangles
    const bottomH = freeRect.height - h;
    const rightW = freeRect.width - w;

    let newFree1: Rect;
    let newFree2: Rect;

    if (rightW < bottomH) {
       // Split Horizontally first
       newFree1 = { x: freeRect.x + w, y: freeRect.y, width: rightW, height: h, rotated: false }; // Right
       newFree2 = { x: freeRect.x, y: freeRect.y + h, width: freeRect.width, height: bottomH, rotated: false }; // Bottom
    } else {
       // Split Vertically first
       newFree1 = { x: freeRect.x, y: freeRect.y + h, width: w, height: bottomH, rotated: false }; // Bottom
       newFree2 = { x: freeRect.x + w, y: freeRect.y, width: rightW, height: freeRect.height, rotated: false }; // Right
    }

    this.freeRectangles.splice(nodeIndex, 1);
    if (newFree1.width > 0 && newFree1.height > 0) this.freeRectangles.push(newFree1);
    if (newFree2.width > 0 && newFree2.height > 0) this.freeRectangles.push(newFree2);

    this.placedRectangles.push(rect);
  }
}

export const optimizeCuts = (
  stockSheets: StockSheet[],
  parts: RequiredPart[],
  kerf: number = 0,
  allowRotation: boolean = true,
  mode: OptimizationMode = 'waste'
): OptimizationResult => {
  
  // Expand parts based on quantity
  let allParts: RequiredPart[] = [];
  parts.forEach(p => {
    for (let i = 0; i < p.quantity; i++) {
      allParts.push({ ...p });
    }
  });

  // Sorting Strategy based on Mode
  allParts.sort((a, b) => {
    const areaA = a.width * a.height;
    const areaB = b.width * b.height;
    const longA = Math.max(a.width, a.height);
    const longB = Math.max(b.width, b.height);
    const shortA = Math.min(a.width, a.height);
    const shortB = Math.min(b.width, b.height);

    if (mode === 'waste') {
      // Default: Sort by Area Descending
      return areaB - areaA;
    } else if (mode === 'long') {
      // Prioritize Longest Dimension
      if (longB !== longA) return longB - longA;
      return areaB - areaA; // tie-breaker
    } else if (mode === 'short') {
      // Prioritize Shortest Dimension (sometimes better for packing uniform widths)
      if (shortB !== shortA) return shortB - shortA;
      return areaB - areaA;
    }
    return areaB - areaA;
  });

  const usedSheets: UsedSheet[] = [];
  const unplacedParts: RequiredPart[] = [];

  // Pool of available stock sheets
  let availableSheetsPool: StockSheet[] = [];
  stockSheets.forEach(s => {
      for(let i=0; i<s.quantity; i++) {
          availableSheetsPool.push({...s});
      }
  });

  if (availableSheetsPool.length === 0) {
      return { sheets: [], unplacedParts: allParts, totalWaste: 0, efficiency: 0 };
  }

  while (allParts.length > 0) {
    let chosenSheetIndex = -1;
    let packer: GuillotinePacker | null = null;

    // Greedy selection: Find first available sheet that fits the largest current part
    for(let i=0; i<availableSheetsPool.length; i++) {
        const sheet = availableSheetsPool[i];
        const p = new GuillotinePacker(sheet.width, sheet.height, kerf);
        const part = allParts[0];
        
        const testRes = p.findBestScore(part.width, part.height, allowRotation);
        if (testRes.score !== Number.MAX_VALUE) {
            chosenSheetIndex = i;
            packer = p;
            break;
        }
    }

    if (chosenSheetIndex === -1) {
        unplacedParts.push(allParts.shift()!);
        continue;
    }

    const currentSheet = availableSheetsPool[chosenSheetIndex];
    availableSheetsPool.splice(chosenSheetIndex, 1);

    const remainingPartsForNext: RequiredPart[] = [];

    // Pack parts into this sheet
    for (const part of allParts) {
        const res = packer!.findBestScore(part.width, part.height, allowRotation);
        if (res.score !== Number.MAX_VALUE) {
            packer!.placeRect(res.rect);
            packer!.placedRectangles[packer!.placedRectangles.length-1].data = part;
        } else {
            remainingPartsForNext.push(part);
        }
    }

    const usedArea = packer!.placedRectangles.reduce((acc, r) => acc + (r.width * r.height), 0);
    const totalArea = currentSheet.width * currentSheet.height;
    const wastePct = ((totalArea - usedArea) / totalArea) * 100;

    usedSheets.push({
        stockId: currentSheet.id,
        width: currentSheet.width,
        height: currentSheet.height,
        cuts: packer!.placedRectangles,
        freeRects: packer!.freeRectangles,
        waste: wastePct
    });

    allParts = remainingPartsForNext;
  }

  const totalStockArea = usedSheets.reduce((acc, s) => acc + (s.width * s.height), 0);
  const totalUsedArea = usedSheets.reduce((acc, s) => {
      return acc + s.cuts.reduce((cAcc, c) => cAcc + (c.width * c.height), 0);
  }, 0);
  
  const efficiency = totalStockArea > 0 ? (totalUsedArea / totalStockArea) * 100 : 0;

  return {
      sheets: usedSheets,
      unplacedParts,
      totalWaste: 100 - efficiency,
      efficiency
  };
};