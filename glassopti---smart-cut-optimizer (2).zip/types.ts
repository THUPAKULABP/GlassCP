
export interface Dimensions {
  width: number;
  height: number;
}

export interface StockSheet {
  id: string;
  width: number;
  height: number;
  quantity: number; // Available quantity
}

export interface RequiredPart {
  id: string;
  label: string;
  width: number;
  height: number;
  quantity: number;
  color?: string;
  description?: string;
}

export interface Rect {
  x: number;
  y: number;
  width: number;
  height: number;
  rotated: boolean;
  data?: RequiredPart; // Link back to original part
}

export interface UsedSheet {
  stockId: string;
  width: number;
  height: number;
  cuts: Rect[];
  waste: number; // Percentage
  freeRects: Rect[]; // Remaining usable areas (internal use)
}

export interface OptimizationResult {
  sheets: UsedSheet[];
  unplacedParts: RequiredPart[];
  totalWaste: number;
  efficiency: number;
}

export type OptimizationMode = 'waste' | 'long' | 'short';

export interface ProjectState {
  stockSheets: StockSheet[];
  parts: RequiredPart[];
  kerf: number;
  allowRotation: boolean;
  timestamp: number;
  unit?: 'mm' | 'inch';
  optimizationMode?: OptimizationMode;
}

export interface Message {
  role: 'user' | 'model';
  text: string;
  timestamp: number;
}
