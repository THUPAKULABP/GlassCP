import React, { useState, useCallback, useRef, useEffect } from 'react';
import { Plus, Trash2, Settings, Calculator, PieChart, AlertCircle, Info, Save, Upload, Box, Layout, ArrowRightLeft, RotateCw, Printer, FileText, CheckCircle, X, Undo2, Redo2, PackageCheck } from 'lucide-react';
import { StockSheet, RequiredPart, OptimizationResult, ProjectState, OptimizationMode } from './types';
import { COLORS, DEFAULT_STOCK, APP_NAME } from './constants';
import { optimizeCuts } from './utils/packer';
import LayoutViewer from './components/LayoutViewer';

const App: React.FC = () => {
  // --- State ---
  const [unit, setUnit] = useState<'mm' | 'inch'>('mm');
  const [stockSheets, setStockSheets] = useState<StockSheet[]>([
    { id: '1', width: 2440, height: 1220, quantity: 10 }
  ]);
  const [parts, setParts] = useState<RequiredPart[]>([
    { id: '1', label: 'Panel A', description: 'Main front panel', width: 800, height: 600, quantity: 2, color: COLORS[0] },
    { id: '2', label: 'Panel B', description: '', width: 400, height: 300, quantity: 5, color: COLORS[1] }
  ]);
  const [kerf, setKerf] = useState<number>(3); // 3mm blade
  const [allowRotation, setAllowRotation] = useState<boolean>(true);
  const [optMode, setOptMode] = useState<OptimizationMode>('waste'); // Optimization Mode
  const [result, setResult] = useState<OptimizationResult | null>(null);
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [viewMode, setViewMode] = useState<'2D' | '3D'>('2D');
  const [notification, setNotification] = useState<{type: 'success' | 'error', message: string} | null>(null);
  
  // History State
  const [history, setHistory] = useState<ProjectState[]>([]);
  const [historyIndex, setHistoryIndex] = useState(-1);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // --- Initialization & History Logic ---

  // Initialize history on mount
  useEffect(() => {
    const initialState: ProjectState = {
      stockSheets,
      parts,
      kerf,
      allowRotation,
      unit,
      timestamp: Date.now(),
      optimizationMode: optMode
    };
    setHistory([initialState]);
    setHistoryIndex(0);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const updateProjectState = useCallback((updates: Partial<ProjectState>) => {
     const newState: ProjectState = {
        stockSheets: updates.stockSheets !== undefined ? updates.stockSheets : stockSheets,
        parts: updates.parts !== undefined ? updates.parts : parts,
        kerf: updates.kerf !== undefined ? updates.kerf : kerf,
        allowRotation: updates.allowRotation !== undefined ? updates.allowRotation : allowRotation,
        unit: updates.unit !== undefined ? updates.unit : unit,
        optimizationMode: updates.optimizationMode !== undefined ? updates.optimizationMode : optMode,
        timestamp: Date.now()
     };

     // Update component state
     if (updates.stockSheets) setStockSheets(updates.stockSheets);
     if (updates.parts) setParts(updates.parts);
     if (updates.kerf !== undefined) setKerf(updates.kerf);
     if (updates.allowRotation !== undefined) setAllowRotation(updates.allowRotation);
     if (updates.unit) setUnit(updates.unit);
     if (updates.optimizationMode) setOptMode(updates.optimizationMode);

     // Update History
     setHistory(prev => {
        const newHistory = prev.slice(0, historyIndex + 1).concat(newState);
        return newHistory;
     });
     setHistoryIndex(prev => prev + 1);
     
     // Clear results on structural changes
     if (updates.stockSheets || updates.parts || updates.unit || updates.optimizationMode) {
         setResult(null);
     }
  }, [stockSheets, parts, kerf, allowRotation, unit, optMode, historyIndex]);

  const handleUndo = useCallback(() => {
    if (historyIndex > 0) {
      const newIndex = historyIndex - 1;
      const state = history[newIndex];
      
      // Restore state
      setStockSheets(state.stockSheets);
      setParts(state.parts);
      setKerf(state.kerf);
      setAllowRotation(state.allowRotation);
      setUnit(state.unit || 'mm');
      setOptMode(state.optimizationMode || 'waste');
      
      setHistoryIndex(newIndex);
      setResult(null); // Invalidate result
      showNotification('success', 'Undo successful');
    }
  }, [history, historyIndex]);

  const handleRedo = useCallback(() => {
    if (historyIndex < history.length - 1) {
      const newIndex = historyIndex + 1;
      const state = history[newIndex];
      
      // Restore state
      setStockSheets(state.stockSheets);
      setParts(state.parts);
      setKerf(state.kerf);
      setAllowRotation(state.allowRotation);
      setUnit(state.unit || 'mm');
      setOptMode(state.optimizationMode || 'waste');
      
      setHistoryIndex(newIndex);
      setResult(null);
      showNotification('success', 'Redo successful');
    }
  }, [history, historyIndex]);

  // Keyboard Shortcuts for Undo/Redo
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
        // Ignore if input is focused (let browser handle text undo)
        if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) {
            return;
        }

        if ((e.metaKey || e.ctrlKey) && e.key === 'z') {
            if (e.shiftKey) {
                e.preventDefault();
                handleRedo();
            } else {
                e.preventDefault();
                handleUndo();
            }
        } else if ((e.metaKey || e.ctrlKey) && e.key === 'y') {
            e.preventDefault();
            handleRedo();
        }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleUndo, handleRedo]);

  // --- Effects ---

  // Auto-dismiss notification
  useEffect(() => {
    if (notification) {
      const timer = setTimeout(() => {
        setNotification(null);
      }, 4000);
      return () => clearTimeout(timer);
    }
  }, [notification]);

  const showNotification = (type: 'success' | 'error', message: string) => {
    setNotification({ type, message });
  };

  // --- Logic Handlers ---

  const toggleUnit = () => {
    const isMM = unit === 'mm';
    const factor = isMM ? 1 / 25.4 : 25.4;
    const newUnit = isMM ? 'inch' : 'mm';
    
    const convert = (n: number) => Number((n * factor).toFixed(3));

    const newStock = stockSheets.map(s => ({...s, width: convert(s.width), height: convert(s.height)}));
    const newParts = parts.map(p => ({...p, width: convert(p.width), height: convert(p.height)}));
    const newKerf = convert(kerf);

    updateProjectState({
        stockSheets: newStock,
        parts: newParts,
        kerf: newKerf,
        unit: newUnit
    });
  };

  const addStock = () => {
    const newStock = [...stockSheets, { 
      id: Date.now().toString(), 
      width: unit === 'mm' ? 2440 : 96, 
      height: unit === 'mm' ? 1220 : 48, 
      quantity: 5 
    }];
    updateProjectState({ stockSheets: newStock });
  };

  const removeStock = (id: string) => {
    const newStock = stockSheets.filter(s => s.id !== id);
    updateProjectState({ stockSheets: newStock });
  };

  const updateStock = (id: string, field: keyof StockSheet, value: number) => {
    // Direct update for UI responsiveness
    setStockSheets(stockSheets.map(s => s.id === id ? { ...s, [field]: value } : s));
  };

  // Commit inputs to history on Blur
  const handleStockBlur = () => {
      updateProjectState({ stockSheets });
  };

  const addPart = () => {
    const color = COLORS[parts.length % COLORS.length];
    const newParts = [...parts, { 
      id: Date.now().toString(), 
      label: `Part ${String.fromCharCode(65 + parts.length)}`, 
      description: '',
      width: unit === 'mm' ? 500 : 20, 
      height: unit === 'mm' ? 500 : 20, 
      quantity: 1,
      color
    }];
    updateProjectState({ parts: newParts });
  };

  const removePart = (id: string) => {
    const newParts = parts.filter(p => p.id !== id);
    updateProjectState({ parts: newParts });
  };

  const updatePart = (id: string, field: keyof RequiredPart, value: string | number) => {
    // Direct update for responsiveness
    setParts(parts.map(p => p.id === id ? { ...p, [field]: value } : p));
  };

  // Commit parts to history on Blur
  const handlePartBlur = () => {
      updateProjectState({ parts });
  };

  const rotatePart = (id: string) => {
    const newParts = parts.map(p => p.id === id ? { ...p, width: p.height, height: p.width } : p);
    updateProjectState({ parts: newParts });
  };
  
  const handleRotationToggle = (checked: boolean) => {
      updateProjectState({ allowRotation: checked });
  };
  
  const handleKerfBlur = () => {
      updateProjectState({ kerf });
  };

  const handleModeChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
      updateProjectState({ optimizationMode: e.target.value as OptimizationMode });
  };

  const handleOptimize = useCallback(() => {
    setNotification(null);
    
    if (stockSheets.length === 0) {
      showNotification('error', 'Please add at least one stock sheet.');
      return;
    }
    if (parts.length === 0) {
      showNotification('error', 'Please add at least one part to cut.');
      return;
    }
    const invalidStock = stockSheets.some(s => s.width <= 0 || s.height <= 0 || s.quantity <= 0);
    if (invalidStock) {
      showNotification('error', 'All stock sheets must have valid positive dimensions and quantity.');
      return;
    }
    const invalidParts = parts.some(p => p.width <= 0 || p.height <= 0 || p.quantity <= 0);
    if (invalidParts) {
      showNotification('error', 'All parts must have valid positive dimensions and quantity.');
      return;
    }

    setIsOptimizing(true);

    setTimeout(() => {
      try {
        const res = optimizeCuts(stockSheets, parts, kerf, allowRotation, optMode);
        setResult(res);
        
        if (res.unplacedParts.length > 0) {
           showNotification('error', `Optimization complete, but ${res.unplacedParts.length} parts could not be placed.`);
        } else {
           showNotification('success', `Optimization complete! Efficiency: ${res.efficiency.toFixed(1)}%`);
        }
      } catch (error) {
        console.error("Optimization failed:", error);
        showNotification('error', 'An unexpected error occurred during optimization. Please check your inputs.');
      } finally {
        setIsOptimizing(false);
      }
    }, 100);
  }, [stockSheets, parts, kerf, allowRotation, optMode]);

  const handlePrintReport = () => {
    window.print();
  };

  // Save & Load
  const handleSave = () => {
    try {
      const projectData: ProjectState = {
        stockSheets,
        parts,
        kerf,
        allowRotation,
        optimizationMode: optMode,
        timestamp: Date.now(),
        unit
      };
      const blob = new Blob([JSON.stringify(projectData, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `glass-project-${new Date().toISOString().slice(0,10)}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      showNotification('success', 'Project saved successfully.');
    } catch (error) {
      showNotification('error', 'Failed to save project file.');
    }
  };

  const handleLoadClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileLoad = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.type !== 'application/json' && !file.name.endsWith('.json')) {
       showNotification('error', 'Invalid file type. Please select a .json project file.');
       e.target.value = ''; 
       return;
    }

    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const rawData = ev.target?.result as string;
        if (!rawData) throw new Error("File is empty");

        const data = JSON.parse(rawData);
        if (!data || typeof data !== 'object') throw new Error("Invalid JSON structure");
        if (!Array.isArray(data.stockSheets)) throw new Error("Missing or invalid 'stockSheets' data");
        if (!Array.isArray(data.parts)) throw new Error("Missing or invalid 'parts' data");

        const isValidStock = data.stockSheets.every((s: any) => 
            s.id && typeof s.width === 'number' && typeof s.height === 'number' && typeof s.quantity === 'number'
        );
        const isValidParts = data.parts.every((p: any) => 
            p.id && typeof p.width === 'number' && typeof p.height === 'number' && typeof p.quantity === 'number'
        );

        if (!isValidStock || !isValidParts) {
            throw new Error("Project file contains invalid data formats for stock or parts.");
        }
        
        const loadedState = {
            stockSheets: data.stockSheets,
            parts: data.parts,
            kerf: typeof data.kerf === 'number' ? data.kerf : (data.unit === 'inch' ? 0.125 : 3),
            allowRotation: data.allowRotation ?? true,
            unit: (data.unit === 'inch' || data.unit === 'mm') ? data.unit : 'mm' as const,
            optimizationMode: (data.optimizationMode === 'waste' || data.optimizationMode === 'long' || data.optimizationMode === 'short') ? data.optimizationMode : 'waste' as const
        };

        updateProjectState(loadedState);
        setResult(null);
        
        showNotification('success', 'Project loaded successfully!');
      } catch (err) {
        console.error("Load error:", err);
        const msg = err instanceof Error ? err.message : 'Failed to parse project file.';
        showNotification('error', msg);
      }
    };
    reader.onerror = () => showNotification('error', 'Error reading file.');
    reader.readAsText(file);
    e.target.value = '';
  };

  // Calculate Stock Usage Stats
  const stockUsage = result ? stockSheets.map(stock => {
      const usedCount = result.sheets.filter(s => s.stockId === stock.id).length;
      return {
          ...stock,
          used: usedCount,
          remaining: stock.quantity - usedCount
      };
  }) : [];

  return (
    <div className="min-h-screen bg-slate-100 text-slate-800 font-sans">
      {/* Toast Notification */}
      {notification && (
          <div className={`fixed bottom-6 right-6 z-[100] flex items-start gap-3 p-4 rounded-lg shadow-xl border max-w-sm animate-[slideIn_0.3s_ease-out] transition-all ${
              notification.type === 'success' ? 'bg-emerald-50 border-emerald-200 text-emerald-800' : 'bg-red-50 border-red-200 text-red-800'
          }`}>
              <div className={`shrink-0 mt-0.5 ${notification.type === 'success' ? 'text-emerald-600' : 'text-red-600'}`}>
                  {notification.type === 'success' ? <CheckCircle size={20} /> : <AlertCircle size={20} />}
              </div>
              <div className="flex-1">
                  <h4 className="font-bold text-sm">{notification.type === 'success' ? 'Success' : 'Error'}</h4>
                  <p className="text-sm opacity-90 leading-tight mt-1">{notification.message}</p>
              </div>
              <button onClick={() => setNotification(null)} className="text-slate-400 hover:text-slate-600">
                  <X size={16} />
              </button>
          </div>
      )}

      {/* Hidden File Input */}
      <input 
        type="file" 
        ref={fileInputRef} 
        className="hidden" 
        accept=".json" 
        onChange={handleFileLoad} 
      />

      {/* Header */}
      <header className="bg-slate-900 text-white p-4 shadow-lg sticky top-0 z-50 print:hidden">
        <div className="container mx-auto flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="bg-indigo-500 p-2 rounded-lg">
              <PieChart size={24} className="text-white" />
            </div>
            <h1 className="text-xl font-bold tracking-tight hidden md:block">{APP_NAME}</h1>
          </div>
          <div className="flex items-center gap-2">
             {/* Undo / Redo */}
             <div className="flex items-center bg-slate-800 rounded-lg p-1 mr-2 border border-slate-700">
                 <button 
                    onClick={handleUndo} 
                    disabled={historyIndex <= 0}
                    className="p-1.5 text-slate-300 hover:text-white hover:bg-slate-700 rounded disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
                    title="Undo (Ctrl+Z)"
                 >
                    <Undo2 size={18} />
                 </button>
                 <div className="w-px h-4 bg-slate-700 mx-1"></div>
                 <button 
                    onClick={handleRedo} 
                    disabled={historyIndex >= history.length - 1}
                    className="p-1.5 text-slate-300 hover:text-white hover:bg-slate-700 rounded disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
                    title="Redo (Ctrl+Y)"
                 >
                    <Redo2 size={18} />
                 </button>
             </div>

             <button onClick={handleLoadClick} className="flex items-center gap-2 px-3 py-1.5 rounded hover:bg-slate-800 text-slate-300 text-sm transition-colors">
                <Upload size={16} /> <span className="hidden sm:inline">Load</span>
             </button>
             <button onClick={handleSave} className="flex items-center gap-2 px-3 py-1.5 rounded hover:bg-slate-800 text-slate-300 text-sm transition-colors">
                <Save size={16} /> <span className="hidden sm:inline">Save</span>
             </button>
          </div>
        </div>
      </header>

      <main className="container mx-auto p-4 md:p-6 lg:p-8 grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Inputs - Hidden on Print */}
        <div className="lg:col-span-4 space-y-6 print:hidden">
          
          {/* Settings Card */}
          <div className="bg-white p-5 rounded-xl shadow-sm border border-slate-200">
            <div className="flex items-center justify-between mb-4 border-b pb-2">
                <div className="flex items-center gap-2 text-slate-700 font-semibold">
                    <Settings size={18} />
                    <h2>Configuration</h2>
                </div>
                <button 
                   onClick={toggleUnit}
                   className="text-xs flex items-center gap-1 bg-slate-100 hover:bg-slate-200 px-2 py-1 rounded text-slate-600 font-medium transition-colors"
                   title="Switch Units"
                >
                    <ArrowRightLeft size={12} />
                    {unit === 'mm' ? 'MM' : 'Inches'}
                </button>
            </div>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="block text-xs font-medium text-slate-500 mb-1">Blade Kerf ({unit})</label>
                    <input 
                    type="number" 
                    step={unit === 'inch' ? "0.001" : "1"}
                    value={kerf} 
                    onChange={(e) => setKerf(Number(e.target.value))}
                    onBlur={handleKerfBlur}
                    className="w-full p-2 border border-slate-300 rounded focus:ring-2 focus:ring-indigo-500 outline-none"
                    />
                </div>
                <div className="flex items-end pb-2">
                    <label className="flex items-center gap-2 cursor-pointer select-none">
                    <input 
                        type="checkbox" 
                        checked={allowRotation} 
                        onChange={(e) => handleRotationToggle(e.target.checked)}
                        className="w-4 h-4 text-indigo-600 rounded focus:ring-indigo-500"
                        />
                    <span className="text-sm text-slate-700">Allow Rotation</span>
                    </label>
                </div>
              </div>
              
              {/* Optimization Mode Selector */}
              <div>
                  <label className="block text-xs font-medium text-slate-500 mb-1">Optimization Goal</label>
                  <select 
                    value={optMode} 
                    onChange={handleModeChange}
                    className="w-full p-2 text-sm border border-slate-300 rounded focus:ring-2 focus:ring-indigo-500 outline-none bg-white"
                  >
                      <option value="waste">Minimize Waste (Best Area)</option>
                      <option value="long">Prioritize Longest Cuts</option>
                      <option value="short">Prioritize Shortest Cuts</option>
                  </select>
              </div>
            </div>
          </div>

          {/* Stock Sheets Card */}
          <div className="bg-white p-5 rounded-xl shadow-sm border border-slate-200">
             <div className="flex justify-between items-center mb-4 border-b pb-2">
                <h2 className="text-slate-700 font-semibold">Stock Sheets</h2>
                <button onClick={addStock} className="text-indigo-600 hover:text-indigo-800 transition-colors p-1">
                  <Plus size={20} />
                </button>
             </div>
             <div className="space-y-3 max-h-[300px] overflow-y-auto pr-1 custom-scrollbar">
               {stockSheets.map((stock) => (
                 <div key={stock.id} className="flex gap-2 items-center bg-slate-50 p-2 rounded border border-slate-100">
                    <div className="flex-1 grid grid-cols-3 gap-2">
                       <div>
                         <label className="text-[10px] text-slate-400 uppercase">Width ({unit})</label>
                         <input 
                            type="number" 
                            value={stock.width} 
                            onChange={(e) => updateStock(stock.id, 'width', Number(e.target.value))}
                            onBlur={handleStockBlur}
                            className="w-full p-1 text-sm border border-slate-300 rounded"
                         />
                       </div>
                       <div>
                         <label className="text-[10px] text-slate-400 uppercase">Height ({unit})</label>
                         <input 
                            type="number" 
                            value={stock.height} 
                            onChange={(e) => updateStock(stock.id, 'height', Number(e.target.value))}
                            onBlur={handleStockBlur}
                            className="w-full p-1 text-sm border border-slate-300 rounded"
                         />
                       </div>
                       <div>
                         <label className="text-[10px] text-slate-400 uppercase">Qty</label>
                         <input 
                            type="number" 
                            value={stock.quantity} 
                            onChange={(e) => updateStock(stock.id, 'quantity', Number(e.target.value))}
                            onBlur={handleStockBlur}
                            className="w-full p-1 text-sm border border-slate-300 rounded"
                         />
                       </div>
                    </div>
                    <button onClick={() => removeStock(stock.id)} className="text-red-400 hover:text-red-600 p-1">
                      <Trash2 size={16} />
                    </button>
                 </div>
               ))}
             </div>
          </div>

          {/* Parts Card */}
          <div className="bg-white p-5 rounded-xl shadow-sm border border-slate-200">
             <div className="flex justify-between items-center mb-4 border-b pb-2">
                <h2 className="text-slate-700 font-semibold">Required Parts</h2>
                <button onClick={addPart} className="text-indigo-600 hover:text-indigo-800 transition-colors p-1">
                  <Plus size={20} />
                </button>
             </div>
             <div className="space-y-3 max-h-[400px] overflow-y-auto pr-1 custom-scrollbar">
               {parts.map((part) => (
                 <div key={part.id} className="flex gap-2 items-start bg-slate-50 p-2 rounded border border-slate-100 relative pl-5">
                    <div 
                        className="absolute left-0 top-0 bottom-0 w-3 rounded-l cursor-pointer hover:brightness-90 transition-all group" 
                        style={{ backgroundColor: part.color || '#3b82f6' }}
                        title="Click to change color"
                    >
                        <input 
                            type="color" 
                            value={part.color || '#3b82f6'}
                            onChange={(e) => updatePart(part.id, 'color', e.target.value)}
                            onBlur={handlePartBlur}
                            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                        />
                    </div>
                    <div className="flex-1 grid grid-cols-12 gap-2">
                       <div className="col-span-12 mb-1">
                         <input 
                            type="text" 
                            value={part.label} 
                            onChange={(e) => updatePart(part.id, 'label', e.target.value)}
                            onBlur={handlePartBlur}
                            className="w-full bg-white text-sm font-medium text-slate-800 p-1.5 border border-slate-300 rounded focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                            placeholder="Part Name / Label"
                         />
                       </div>
                       <div className="col-span-3">
                         <input 
                            type="number" 
                            value={part.width} 
                            onChange={(e) => updatePart(part.id, 'width', Number(e.target.value))}
                            onBlur={handlePartBlur}
                            className="w-full p-1 text-sm border border-slate-300 rounded"
                            placeholder={`W`}
                         />
                       </div>
                       <div className="col-span-1 flex items-center justify-center">
                          <button 
                            onClick={() => rotatePart(part.id)}
                            className="text-slate-400 hover:text-indigo-600 transition-all hover:rotate-90 cursor-grab active:cursor-grabbing active:scale-90 p-1"
                            title="Rotate 90° (Swap W/H)"
                          >
                            <RotateCw size={14} />
                          </button>
                       </div>
                       <div className="col-span-3">
                         <input 
                            type="number" 
                            value={part.height} 
                            onChange={(e) => updatePart(part.id, 'height', Number(e.target.value))}
                            onBlur={handlePartBlur}
                            className="w-full p-1 text-sm border border-slate-300 rounded"
                            placeholder={`H`}
                         />
                       </div>
                       <div className="col-span-3">
                         <input 
                            type="number" 
                            value={part.quantity} 
                            onChange={(e) => updatePart(part.id, 'quantity', Number(e.target.value))}
                            onBlur={handlePartBlur}
                            className="w-full p-1 text-sm border border-slate-300 rounded"
                            placeholder="Qty"
                         />
                       </div>
                       <div className="col-span-2 flex justify-end items-center">
                          <button onClick={() => removePart(part.id)} className="text-red-400 hover:text-red-600">
                            <Trash2 size={16} />
                          </button>
                       </div>
                       
                       {/* Description Text Area */}
                       <div className="col-span-12 mt-1">
                          <textarea 
                              value={part.description || ''}
                              onChange={(e) => updatePart(part.id, 'description', e.target.value)}
                              onBlur={handlePartBlur}
                              placeholder="Part description (optional)..."
                              className="w-full text-xs p-1.5 border border-slate-200 rounded bg-white focus:bg-white focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 transition-all resize-y min-h-[2.5rem]"
                              rows={2}
                          />
                       </div>
                    </div>
                 </div>
               ))}
             </div>
          </div>

          <button 
            onClick={handleOptimize}
            disabled={isOptimizing || parts.length === 0 || stockSheets.length === 0}
            className="w-full bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white font-bold py-4 rounded-xl shadow-lg shadow-indigo-200 transition-all flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isOptimizing ? (
              <>Computing...</>
            ) : (
              <><Calculator size={20} /> Optimize Cut Layout</>
            )}
          </button>

        </div>

        {/* Right Column: Results & Visualization - Full width on Print */}
        <div className="lg:col-span-8 print:col-span-12 print:w-full">
          
          {/* Header with View Toggle */}
          <div className="flex justify-between items-center mb-4 pb-4 border-b border-slate-200 print:hidden">
              <h2 className="text-xl font-bold text-slate-800 flex items-center gap-2">
                <Layout size={24} className="text-indigo-600"/>
                Optimization Results
              </h2>
             
             {result && (
                 <div className="flex items-center gap-3">
                     <button
                       onClick={handlePrintReport}
                       className="flex items-center gap-2 px-3 py-1.5 bg-slate-800 text-white text-sm rounded hover:bg-slate-700 transition-colors"
                       title="Print Full Report / Save as PDF"
                     >
                        <FileText size={16} />
                        <span className="hidden md:inline">Print Report</span>
                     </button>

                     <div className="flex bg-slate-200 rounded-lg p-1">
                         <button 
                           onClick={() => setViewMode('2D')}
                           className={`px-3 py-1 text-sm rounded-md transition-all ${viewMode === '2D' ? 'bg-white text-indigo-600 shadow-sm font-bold' : 'text-slate-600 hover:text-slate-800'}`}
                         >
                            2D
                         </button>
                         <button 
                           onClick={() => setViewMode('3D')}
                           className={`px-3 py-1 text-sm rounded-md transition-all ${viewMode === '3D' ? 'bg-white text-indigo-600 shadow-sm font-bold' : 'text-slate-600 hover:text-slate-800'}`}
                         >
                            3D
                         </button>
                     </div>
                 </div>
             )}
          </div>

          <div className="bg-slate-50 rounded-xl min-h-[500px] border border-slate-200 p-4 md:p-6 print:border-none print:bg-white print:p-0">
               {!result ? (
                  <div className="h-full flex flex-col items-center justify-center text-slate-400 opacity-60 mt-20">
                     <Layout size={64} className="mb-4" />
                     <p className="text-lg font-medium">Enter dimensions and click Optimize</p>
                  </div>
               ) : (
                  <div>
                     {/* Print Header for Report */}
                     <div className="hidden print:block mb-6 pb-4 border-b-2 border-slate-800">
                         <h1 className="text-3xl font-bold text-slate-900 mb-2">Optimization Report</h1>
                         <div className="text-sm text-slate-600 flex justify-between">
                             <span>Project: Glass Cut Layout</span>
                             <span>Date: {new Date().toLocaleDateString()}</span>
                         </div>
                     </div>

                     {/* Summary Stats */}
                     <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8 print:grid-cols-3 print:gap-6 print:mb-8">
                        <div className="bg-white p-4 rounded-lg shadow-sm border border-slate-100 print:border-slate-300">
                           <div className="text-slate-500 text-xs font-bold uppercase tracking-wider mb-1">Efficiency</div>
                           <div className="text-2xl font-bold text-indigo-600">{result.efficiency.toFixed(1)}%</div>
                           <div className="w-full bg-slate-100 h-1.5 rounded-full mt-2 overflow-hidden print:hidden">
                              <div className="bg-indigo-500 h-full rounded-full" style={{width: `${result.efficiency}%`}}></div>
                           </div>
                        </div>
                        <div className="bg-white p-4 rounded-lg shadow-sm border border-slate-100 print:border-slate-300">
                           <div className="text-slate-500 text-xs font-bold uppercase tracking-wider mb-1">Sheets Used</div>
                           <div className="text-2xl font-bold text-slate-800">{result.sheets.length}</div>
                           <div className="text-xs text-slate-400 mt-1">From {stockSheets.reduce((acc, s) => acc + s.quantity, 0)} available</div>
                        </div>
                        <div className="bg-white p-4 rounded-lg shadow-sm border border-slate-100 print:border-slate-300">
                           <div className="text-slate-500 text-xs font-bold uppercase tracking-wider mb-1">Unplaced Parts</div>
                           <div className={`text-2xl font-bold ${result.unplacedParts.length > 0 ? 'text-red-500' : 'text-emerald-500'}`}>
                              {result.unplacedParts.length}
                           </div>
                           <div className="text-xs text-slate-400 mt-1">
                              {result.unplacedParts.length > 0 ? 'Try adding more stock' : 'All parts optimized'}
                           </div>
                        </div>
                     </div>

                     {/* Stock Usage Report Table */}
                     <div className="mb-8 bg-white rounded-lg border border-slate-200 overflow-hidden print:border-slate-300">
                         <div className="bg-slate-100 px-4 py-2 border-b border-slate-200 font-semibold text-sm text-slate-700 flex items-center gap-2 print:bg-slate-200">
                             <PackageCheck size={16} />
                             <h3>Stock Usage Report</h3>
                         </div>
                         <table className="w-full text-sm text-left">
                             <thead className="bg-slate-50 text-slate-500 font-medium">
                                 <tr>
                                     <th className="px-4 py-2">Stock Size</th>
                                     <th className="px-4 py-2 text-center">Total Available</th>
                                     <th className="px-4 py-2 text-center">Used</th>
                                     <th className="px-4 py-2 text-center">Remaining</th>
                                 </tr>
                             </thead>
                             <tbody className="divide-y divide-slate-100">
                                 {stockUsage.map(stock => (
                                     <tr key={stock.id}>
                                         <td className="px-4 py-2 font-medium text-slate-700">
                                             {stock.width} x {stock.height} {unit}
                                         </td>
                                         <td className="px-4 py-2 text-center text-slate-600">{stock.quantity}</td>
                                         <td className="px-4 py-2 text-center font-bold text-indigo-600">{stock.used}</td>
                                         <td className={`px-4 py-2 text-center font-bold ${stock.remaining === 0 ? 'text-red-400' : 'text-emerald-500'}`}>
                                             {stock.remaining}
                                         </td>
                                     </tr>
                                 ))}
                             </tbody>
                         </table>
                     </div>

                     {/* Cut List Detail Table */}
                     <div className="mb-8 bg-white rounded-lg border border-slate-200 overflow-hidden print:border-slate-300 print:break-before">
                          <div className="bg-slate-100 px-4 py-2 border-b border-slate-200 font-semibold text-sm text-slate-700 flex items-center gap-2 print:bg-slate-200">
                              <Box size={16} />
                              <h3>Part List Summary</h3>
                          </div>
                          <table className="w-full text-sm text-left">
                              <thead className="bg-slate-50 text-slate-500 font-medium">
                                  <tr>
                                      <th className="px-4 py-2">Label</th>
                                      <th className="px-4 py-2">Dimensions</th>
                                      <th className="px-4 py-2 text-center">Qty</th>
                                      <th className="px-4 py-2">Description</th>
                                      <th className="px-4 py-2 text-center">Status</th>
                                  </tr>
                              </thead>
                              <tbody className="divide-y divide-slate-100">
                                  {parts.map(part => {
                                      const unplaced = result.unplacedParts.filter(up => up.label === part.label && up.width === part.width && up.height === part.height).length;
                                      return (
                                          <tr key={part.id}>
                                              <td className="px-4 py-2 font-medium text-slate-800">{part.label}</td>
                                              <td className="px-4 py-2 text-slate-600">{part.width} x {part.height} {unit}</td>
                                              <td className="px-4 py-2 text-center">{part.quantity}</td>
                                              <td className="px-4 py-2 text-slate-500 italic text-xs">{part.description || '-'}</td>
                                              <td className="px-4 py-2 text-center">
                                                  {unplaced === 0 ? (
                                                      <span className="inline-flex items-center gap-1 text-emerald-600 text-xs font-bold bg-emerald-50 px-2 py-1 rounded-full">
                                                          <CheckCircle size={12} /> All Placed
                                                      </span>
                                                  ) : (
                                                      <span className="inline-flex items-center gap-1 text-red-600 text-xs font-bold bg-red-50 px-2 py-1 rounded-full">
                                                          <AlertCircle size={12} /> {unplaced} Missing
                                                      </span>
                                                  )}
                                              </td>
                                          </tr>
                                      );
                                  })}
                              </tbody>
                          </table>
                     </div>

                     {/* Unplaced Warning */}
                     {result.unplacedParts.length > 0 && (
                        <div className="bg-red-50 border-l-4 border-red-500 p-4 mb-6 rounded-r-lg flex items-start gap-3 print:bg-white print:border print:border-red-200">
                           <AlertCircle className="text-red-500 shrink-0 mt-0.5" />
                           <div>
                              <h3 className="font-bold text-red-700">Attention Needed</h3>
                              <p className="text-sm text-red-600 mt-1">
                                 The following parts could not be placed: 
                                 {result.unplacedParts.map((p, i) => (
                                    <span key={i} className="font-mono font-bold mx-1 bg-red-100 px-1 rounded">
                                       {p.label} ({p.width}x{p.height})
                                    </span>
                                 ))}
                              </p>
                           </div>
                        </div>
                     )}

                     {/* Sheets Render */}
                     <div className="space-y-8 print:space-y-0">
                        {result.sheets.map((sheet, idx) => (
                           <div key={idx} className="print:break-before print:mb-8">
                               <LayoutViewer 
                                  sheet={sheet} 
                                  index={idx} 
                                  is3D={viewMode === '3D'}
                                  unit={unit}
                               />
                           </div>
                        ))}
                     </div>
                  </div>
               )}
            </div>
        </div>
      </main>
    </div>
  );
};

export default App;